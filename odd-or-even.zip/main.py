n=int(input("enter a number"))
x=1
if(n%2==0):
    x=0
print(x)